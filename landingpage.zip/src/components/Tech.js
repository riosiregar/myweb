import React, { useEffect } from 'react';
import '../styles/Tech.css';

const Tech = () => {
  useEffect(() => {
    const handleScroll = () => {
      const elements = document.querySelectorAll('.fade-in');
      elements.forEach((el) => {
        const position = el.getBoundingClientRect().top;
        const screenPosition = window.innerHeight / 1.3;

        if (position < screenPosition) {
          el.classList.add('visible');
        }
      });
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section id="tech" className="bg-light py-5">
      <div className="container">
        <h2 className="text-center mb-5">Our Technology Stack</h2>
        <div className="row">
          {[
            { icon: 'html5', name: 'HTML5' },
            { icon: 'css3-alt', name: 'CSS3' },
            { icon: 'js-square', name: 'JavaScript' },
            { icon: 'react', name: 'React' },
            { icon: 'node-js', name: 'Node.js' },
            { icon: 'aws', name: 'AWS' },
          ].map((tech, index) => (
            <div key={index} className="col-lg-4 col-md-6 mb-4 fade-in">
              <div className="card">
                <div className="card-body text-center">
                  <i className={`fab fa-${tech.icon} fa-3x mb-3`}></i>
                  <h3 className="card-title">{tech.name}</h3>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Tech;
