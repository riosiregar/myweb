import React from 'react';
import '../styles/About.css';

const About = () => {
  return (
    <section id="about" className="py-5">
      <div className="container text-center">
        <h2>About ALPHA CORTEX</h2>
        <p className="lead">We are dedicated to empowering developers and businesses with innovative digital solutions.</p>
        <a href="#contact" className="btn btn-primary btn-lg mt-3">Get in Touch</a>
      </div>
    </section>
  );
};

export default About;
